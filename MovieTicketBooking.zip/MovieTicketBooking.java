package com.swingex;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class MovieTicketBooking {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new BookingFrame().setVisible(true);
        });
    }
}

class Movie {
    private String title;
    private int availableSeats;
    private String time;
    private final int totalSeats;
    private final double ticketPrice;

    public Movie(String title, int availableSeats,String time,double ticketPrice) {
        this.title = title;
        this.availableSeats = availableSeats;
        this.time=time;
        this.totalSeats = availableSeats;
        this.ticketPrice = ticketPrice;
    }

    public String getTitle() {
        return title;
    }

    public int getAvailableSeats() {
        return availableSeats;
    }

    public String getTime() { 
        return time;
    }
    public double getTicketPrice() {
        return ticketPrice;
    }
    public void bookSeat() {
        if (availableSeats > 0) {
            availableSeats--;
        } else {
            throw new RuntimeException("No seats available");
        }
    }

    public int getTotalSeats() {
        return totalSeats;
    }
    public int getBookedSeats() {
            return totalSeats - availableSeats;
    }
    @Override
    public String toString() {
        return title;
    }
}

class Booking {
    private Movie movie;
    private String personName;
    private int bookedSeats;

    public Booking(Movie movie,String personName,int bookedSeats) {
        this.movie = movie;
        this.personName=personName;
        this.bookedSeats=bookedSeats;
    }
    public void bookTicket() {
        try {
            for (int i = 0; i < bookedSeats; i++){
            movie.bookSeat();
        }
        double totalCost = bookedSeats * movie.getTicketPrice();
            saveBookingDetails();
            JOptionPane.showMessageDialog(null,
            "Ticket booked for " + movie.getTitle() + " at " + movie.getTime() +
                    "\nName: " + personName +
                    "\nTotal seats: " + movie.getTotalSeats() +
                    "\nBooked seats: " + movie.getBookedSeats() +
                    "\nTotal Cost: $" + totalCost,
            "Booking Confirmation",
            JOptionPane.INFORMATION_MESSAGE);
       } catch (RuntimeException e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
       }
    }private void saveBookingDetails() {
                try (BufferedWriter writer = new BufferedWriter(new FileWriter("bookings.txt", true))) {
                    writer.write("Name: " + personName + ", Movie: " + movie.getTitle() + ", Seats: " + bookedSeats);
                    writer.newLine();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }

class BookingFrame extends JFrame {
    private JComboBox<Movie> movieComboBox;
    private JButton bookButton;
    private JButton selectSeatsButton;
    private JTextField nameField;

    public BookingFrame() {
        setTitle("Movie Ticket Booking");
        setSize(200, 200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new FlowLayout());

        // Sample Movies
        Movie[] movies = {
            new Movie("Avengers: Endgame", 8, "12:00 PM", 15.00),
            new Movie("The Lion King", 10, "5:00 PM", 12.00),
            new Movie("Joker", 3, "7:00 PM", 10.00)
        };

        movieComboBox = new JComboBox<>(movies);
        bookButton = new JButton("Book Ticket");
        selectSeatsButton = new JButton("Select Seats");
        nameField = new JTextField(15);

        add(new JLabel("Enter your name:")); // Label for the name input
        add(nameField);
        add(movieComboBox);
        add(bookButton);
        add(selectSeatsButton);

        bookButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Movie selectedMovie = (Movie) movieComboBox.getSelectedItem();
                String personName = nameField.getText();
                if (personName.trim().isEmpty()) {
                    JOptionPane.showMessageDialog(null, "Please enter your name.");
                    return;
                }
                if (selectedMovie.getAvailableSeats() > 0) {
                    Booking booking = new Booking(selectedMovie,personName,5);
                    booking.bookTicket();
                } else {
                    JOptionPane.showMessageDialog(null, "No seats available for " + selectedMovie.getTitle());
                }
            }
        });

        selectSeatsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Movie selectedMovie = (Movie) movieComboBox.getSelectedItem();
                String personName = nameField.getText();

                if (selectedMovie.getAvailableSeats() > 0) {
                    new SeatSelectionFrame(selectedMovie).setVisible(true);
                } else {
                    JOptionPane.showMessageDialog(null, "No seats available for " + selectedMovie.getTitle());
                }
            }
        });

        add(movieComboBox);
        add(bookButton);
        add(selectSeatsButton);
    }
}

 class SeatSelectionFrame extends JFrame {
     JButton[][] seats;
     Movie movie;
     int rows = 5; // Number of rows
     int cols = 5; // Number of columns
     int bookedSeats = 0;
     String personName;

    public SeatSelectionFrame(Movie movie) {
        this.movie = movie;
        setTitle("Select Seats for " + movie.getTitle());
        setSize(200, 200);
        setLayout(new GridLayout(rows + 1, cols));

        GridBagConstraints gbc = new GridBagConstraints(); // Declare and initialize gbc
        JPanel seatPanel = new JPanel(new GridLayout(rows, cols)); // Declare seatPanel

        seats = new JButton[rows][cols];
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                seats[i][j] = new JButton("Available");
                final int row = i;
                final int col = j;

                seats[i][j].addActionListener(e -> {
                    if (seats[row][col].getText().equals("Available")) {
                        seats[row][col].setText("Booked");
                        bookedSeats++;
                        seats[row][col].setBackground(Color.RED); 
                    } else {
                        seats[row][col].setText("Available");
                        bookedSeats--;
                        seats[row][col].setBackground(null);
                    }
                });
                seatPanel.add(seats[i][j]);
    }
}
gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.weightx = 1;
        gbc.weighty = 1;
        gbc.fill = GridBagConstraints.BOTH;
        add(seatPanel, gbc);

        JButton confirmButton = new JButton("Confirm Booking");
        confirmButton.addActionListener(e -> confirmBooking());
        gbc.gridy = 1;
        gbc.weighty = 0;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        add(confirmButton, gbc);
}
private void confirmBooking() {
    if (bookedSeats > 0) {
        int response = JOptionPane.showConfirmDialog(this, 
            "Do you want to confirm booking for " + bookedSeats + " seat(s)?", 
            "Confirm Booking", 
            JOptionPane.YES_NO_OPTION);
        
        if (response == JOptionPane.YES_OPTION) {
            Booking booking = new Booking(movie, "xyz", bookedSeats); // Replace "Person Name" with actual name if needed
            booking.bookTicket(); // Call to book the ticket
            dispose();
            JOptionPane.showMessageDialog(this, "Booking confirmed for " + bookedSeats + " seat(s).");

            movie.bookSeat();
            
            dispose(); // Close the seat selection frame
        }
    } else {
        JOptionPane.showMessageDialog(this, "Please select at least one seat.");
    }
}
}